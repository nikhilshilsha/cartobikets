export const stepFormLi = [
  {
    stepName: "1. My Account",
    stepIndex: 1,
  },
  {
    stepName: "2.My store",
    stepIndex: 2,
  },
  {
    stepName: "3.Account Validation",
    stepIndex: 3,
  },
  {
    stepName: "4.manager role",
    stepIndex: 4,
  },
];
export const stepFormLimobile = [
  {
    stepName: "1",
    stepIndex: 1,
  },
  {
    stepName: "2",
    stepIndex: 2,
  },
  {
    stepName: "3",
    stepIndex: 3,
  },
  {
    stepName: "4",
    stepIndex: 4,
  },
];
