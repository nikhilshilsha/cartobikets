import Logo from '../../images/logo.png';
import SmallLogo from '../../images/photo_cartobike.png';
import Contact from '../../images/default-user.png';
import Add from '../../images/drops.gif';
import Order from '../../images/order.svg';
import Message from '../../images/Groupmessage.svg';
import Notify from '../../images/notify.svg';
import Flag from '../../images/us.svg';
import Eng from '../../images/us.svg';
import French from '../../images/fr.svg';
import Dutch from '../../images/nl.svg';
import ShwLogo from '../../images/default-vehicle.png';
import Boutiqu from '../../images/default-vehicle.png';
import Boutiqu2 from '../../images/default-slider.png';
import LogoContact from '../../images/default-user.png';
import Car1 from '../../images/slider/05.jpg';
import Car2 from '../../images/default-vehicle.png';
import Default from '../../images/default-slider.png';
import Close from '../../images/close.png';
import InProgress from '../../images/auction-inprogress.png';
import InProgress2 from '../../images/auction-tomorrow.png';
import Imge from '../../images/mercedes-maybach.jpg';

import InProgress3 from '../../images/auction-after-tomorrow.png';
import Avtar from '../../images/avatars/avatar-2.png';
import AboutImg2 from '../../images/about/img_2.jpg';
import Star1 from '../../images/star.jpg';
import Arrow from '../../images/arrow.png';
import Pasword from '../../images/illu-8.png';
import LoginImg from '../../images/illu-2.png';
import Sign from '../../images/illu-5.png';
import Particular from '../../images/accou_par.png';
import Professional from '../../images/accou_pro.png';
import Blog from '../../images/mercedes-maybach.jpg';
import Blog2 from '../../images/mercedes-maybach.jpg';

import Blog3 from '../../images/mercedes-maybach.jpg';
import Profile from '../../images/default-user.png';
import Vecle from '../../images/default-img.png';
import CarImage from '../../images/illu-1.png';
import CarImage1 from '../../images/acceuil2.png';
import LogoImg from '../../images/logo_w.png';
import AboutImg1 from '../../images/about/img_1.jpg';
import Avtar1 from '../../images/avatars/avatar-8.png';
import Car from '../../images/acceuil1.png';

export {
  Logo,
  SmallLogo,
  Contact,
  Add,
  Order,
  Message,
  Notify,
  Flag,
  Eng,
  French,
  Dutch,
  ShwLogo,
  Boutiqu,
  Boutiqu2,
  LogoContact,
  Default,
  Car1,
  Car2,
  Close,
  InProgress2,
  InProgress,
  Imge,
  InProgress3,
  Avtar,
  AboutImg2,
  Star1,
  Arrow,
  Pasword,
  LoginImg,
  Sign,
  Particular,
  Professional,
  Blog,
  Blog2,
  Blog3,
  Profile,
  Vecle,
  CarImage,
  CarImage1,
  LogoImg,
  AboutImg1,
  Avtar1,
  Car,
};
